#ifndef DAY13_STU_H
#define DAY13_STU_H

#include <iostream>
using namespace std;

class stu{
public:
    string name;
    stu();
    stu(string name);

    void run();
    ~stu();

};

#endif
